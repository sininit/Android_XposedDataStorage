package top.fols.aapp.xp.estronge;

import java.io.File;

public class XEnvironmentUtils {

    public static final File[] SELF_PRIMARY = new File[]{
        new File("/sdcard/"),
        new File("/storage/self/primary/"),
        new File("/mnt/sdcard")
    };
    public static File getSelfPrimary() {
        File good = XEnvironmentUtils.SELF_PRIMARY[0];
        long goodMod = 0;
        for (File file: SELF_PRIMARY) {
            long mod = 0L;

            if (file.exists()) { mod += 4L; }
            if (file.canRead()) { mod += 2L; }
            if (file.canWrite()) { mod += 1L; }
            if (mod > goodMod) { goodMod = mod; good = file; }
        }
        return good;
    }
    public static String getSelfPrimaryPath() {
        return XEnvironmentUtils.getSelfPrimary().getAbsolutePath();
    }
}

