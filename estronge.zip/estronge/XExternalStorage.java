package top.fols.aapp.xp.estronge;

import android.content.Context;
import android.content.pm.PackageManager;
import java.io.File;
import java.io.IOException;

/**
 * SDK >= 4.4 no need authority
 * 
 * SDK < 4.4
 * <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE"
 * android:maxSdkVersion="18"/>
 */
public class XExternalStorage {

    /**
     * @see android.os.Environment
     */
    private static final String DIR_ANDROID = "Android";
    private static final String DIR_DATA = "data"; 
    private static final String DIR_FILES = "files";
    
    
    
    
    
    public static Context createContext(Context baseContext, String packageName) throws PackageManager.NameNotFoundException {
        return baseContext.createPackageContext(packageName, Context.CONTEXT_IGNORE_SECURITY);
    }

    //SDCard/Android/data/你的应用的包名/files/
    public static File getFilsDir(Context context) {
        return context.getExternalFilesDir("");
    }
    public static File getFilsDir(String packageName) {
        return new File(XEnvironmentUtils.getSelfPrimaryPath() +
            File.separator + DIR_ANDROID +
            File.separator + DIR_DATA +
            File.separator + packageName +
            File.separator + DIR_FILES);
    }

    /**
     * create file must use this method
     */
    public static File createFilesFile(Context context, String dir, String fileName) throws IOException {
        File file = getFilesFile(context, dir, fileName);
        if (!file.exists()) {
            file.getParentFile().mkdirs();
            file.createNewFile();
        }
        return file;
    }


    public static File getFilesFile(Context context, String dir, String fileName) {
        File file = new File(new File(getFilsDir(context), dir), fileName);
        return file;
    }

    public static File getFilesFile(String packageName, String dir, String fileName) {
        File file = new File(new File(getFilsDir(packageName), dir), fileName);
        return file;
    }




    private Context mBaseContext;
    private Context mAccessContext;
    private String mAccessPackageName;
    public XExternalStorage(Context baseContext)throws NullPointerException {
        if (null == baseContext) {
            throw new NullPointerException("context");
        }
        this.mAccessPackageName = (this.mAccessContext = this.mBaseContext = baseContext).getPackageName();
    }

    public XExternalStorage setAccessPackageContext(String packageName) throws PackageManager.NameNotFoundException {
        return this.setAccessPackageContext(this.createContext(this.getBaseContext(), packageName));
    }
    public XExternalStorage setAccessPackageContext(Context context) throws PackageManager.NameNotFoundException {
        if (null == context) {
            throw new PackageManager.NameNotFoundException("null");
        }
        this.mAccessContext = context;
        this.mAccessPackageName = context.getPackageName();
        return this;
    }

    public Context getBaseContext() {
        return this.mBaseContext;
    }

    public Context getAccessPackageContext() {
        return this.mAccessContext;
    }
    public String getAccessPackageName() {
        return this.mAccessPackageName;
    }

    public File createFilesFile(String dir, String fileName) throws IOException {
        return this.createFilesFile(this.getAccessPackageContext(), dir, fileName);
    }

    public File getFilesFile(String dir, String fileName) {
        return this.getFilesFile(this.getAccessPackageContext(), dir, fileName);
    }

    public File getFilsDir() {
        return this.getFilsDir(this.getAccessPackageContext());
    }


}

